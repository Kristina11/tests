import React, { Component } from 'react';
import Navbar from './components/Navbar/Navbar';
import data from './data/navigation.json';
import './App.css';

class App extends Component {

  constructor(props){
    super(props)
  }
  render(){
    return (
      <div className="App">
        <Navbar data={data} />
      </div>
    );
  }
}

export default App;
