import React, { Component } from 'react';
import './Navbar.css';
const styles = {
    transition: 'all 1s ease-out'
}
class Navbar extends Component {

    constructor(props){
        super(props);

        this.state = {
            posX: 0,
            width: '0'
        };
    }

    onMove(event){
        event.preventDefault();
        this.setState({
            posX: event.clientX - event.target.offsetWidth,
            width: event.target.offsetWidth
        });
    }
    render(){      
        return (
            <header>
                <nav>
                    <div>
                        <ul>
                            {this.props.data.cities.map((city,i) => (
                                <li onClick={this.onMove.bind(this)} key={city.section}>
                                    <a href={city.section}>{city.label}</a>
                                </li>
                            ))}
                        </ul>
                        <div style={{...styles, 
                        width: this.state.width+'px', 
                        transform: 'translate('+this.state.posX+'px, 0px)'}} className="slider"></div>
                    </div>         
                </nav>
            </header>
        )
    }
}


export default Navbar;