import React, { Component } from 'react';

import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';

import StackedChartOptions from '../components/charts/StackedOptions';
import MapChartOptions from '../components/charts/MapOptions';

import WorldMapData from '../data/world-map.json';
import CountryCodes from '../data/country-codes-lat-long-alpha3.json';

// Add latitude, longitude, Country Name
const setMapData = [];
WorldMapData.hits.hits.map(function (data) {
    CountryCodes.ref_country_codes.map(function (code) {
        if (data._source.Country === code.alpha2) {
            setMapData.push({ data, code });
        }
    })
});

const stackedDate = [];
const stackedNumber = [];
const stackedName = [];
// Prepare Chart Data
const mapData = setMapData.map(data => {
    stackedDate.push(data.data._source.Date);
    stackedNumber.push(data.data._source.Perc_lt_30ms);
    stackedName.push({ 'name': data.code.alpha2, 'data': stackedNumber });
    return {
        z: 10,
        countryCode: data.code.alpha2,
        countryName: data.code.country,
        lat: data.code.latitude,
        lon: data.code.longitude,
        date: data.data._source.Date,
        id: data.data._id,
        perc_30ms_60ms: data.data._source.Perc_30ms_60ms,
        perc_60ms_90ms: data.data._source.Perc_60ms_90ms,
        perc_90ms_150ms: data.data._source.Perc_90ms_150ms,
        perc_gt_150ms: data.data._source.Perc_gt_150ms,
        perc_lt_30ms: data.data._source.Perc_lt_30ms,
        totalCount: data.data._source.TotalCount
    }
});

// Build Highchart component
class WorldPopulationChart extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            stackedChartOptions: StackedChartOptions('World Population', stackedDate, stackedNumber, 'Perce Lt 30 ms', stackedName),
            mapChartOptions: MapChartOptions('World Population Density map / Countries', 'Population density per km²', 'Perce Lt 30 ms', mapData)
        };
    }

    componentDidMount() {
        this.mapChartRef = React.createRef();
        this.stackChartRef = React.createRef();
    }

    render() {
        const { stackedChartOptions, mapChartOptions } = this.state;
        return (
            <div>
                <HighchartsReact 
                    highcharts={Highcharts} 
                    constructorType={'mapChart'} 
                    options={mapChartOptions} 
                    ref={this.mapChartRef}
                    containerProps = {{ className: 'chartContainer' }} />
                <HighchartsReact 
                    highcharts={Highcharts} 
                    options={stackedChartOptions} 
                    ref={this.stackChartRef} />
            </div>
        );
    }
}

export default WorldPopulationChart;