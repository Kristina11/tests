import Highcharts from 'highcharts';
import mapDataWorld from '@highcharts/map-collection/custom/world.geo.json';
import highchartsMap from 'highcharts/modules/map';
import proj4 from 'proj4';
highchartsMap(Highcharts);

if (typeof window !== "undefined") {
    window.proj4 = window.proj4 || proj4;
}

export default function MapOptions(title, legend, name, data){
    return {
        chart: {
            map: 'custom/world',
            height: 500
        },
        title: {
            text: title
        },
        legend: {
            title: {
                text: legend,
                style: {
                    color: ( // theme
                        Highcharts.defaultOptions &&
                        Highcharts.defaultOptions.legend &&
                        Highcharts.defaultOptions.legend.title &&
                        Highcharts.defaultOptions.legend.title.style &&
                        Highcharts.defaultOptions.legend.title.style.color
                    ) || 'black'
                }
            }
        },
        mapNavigation: {
            enabled: true,
            buttonOptions: {
                verticalAlign: 'bottom'
            }
        },
        tooltip: {
            backgroundColor: '#fff',
            borderWidth: 2,
            shadow: true,
            useHTML: true,
            padding: 20,
            pointFormat: '<span class="f32"><span class="flag {point.properties.hc-key}">' +
                '</span></span> ' +
                '<h2>{point.countryName}</h2>' +
                '<h3> {point.totalCount:.1f}</h3>' +
                '<h4> {point.date}</h4>' +
                '<div> 30ms - 60ms: {point.perc_30ms_60ms:.2f}</div>' +
                '<div> 60ms - 90ms: {point.perc_60ms_90ms:.2f}</div>' +
                '<div> 90ms - 150ms: {point.perc_90ms_150ms:.2f}</div>' +
                '<div> Greater then 150ms: {point.perc_gt_150ms:.2f}</div>' +
                '<div> Less then 30ms: {point.perc_lt_30ms:.2f}</div>',
            positioner: function () {
                return { x: 0, y: 250 };
                }
        }, 
        colorAxis: {
            min: 1,
            max: 1000,
            type: 'logarithmic'
        },  
        xAxis: {
            crosshair: {
                zIndex: 5,
                dashStyle: 'dot',
                snap: false,
                color: 'gray'
            }
        }, 
        yAxis: {
            crosshair: {
                zIndex: 5,
                dashStyle: 'dot',
                snap: false,
                color: 'gray'
            }
        },
        plotOptions: {
            bubble: {
                minSize: 3,
                maxSize: 5
            }
        },
        series: [{
            mapData: mapDataWorld,
            joinBy: ['iso-a2', 'code'],
            name: name,
            borderColor: '#606060',
            nullColor: 'rgba(200, 200, 200, 0.2)',
            states: {
                hover: {
                    color: '#a4edba'
                }
            }
        },
        {
            type: "mapbubble",
            minSize: 2,
            maxSize: '5%',
            dataLabels: {
                enabled: true,
                format: '{point.countryCode}'
            },
            name: "<b>Country</b>",
            color: "#4169E1",
            data: data,
            cursor: "pointer",
            point: {
                events: {
                    click: function () {
                        console.log(this.countryCode, this.date, this.perc_lt_30ms);
                    }
                }
            }
        }]
    }
}